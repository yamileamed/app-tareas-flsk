# App de Tareas (To-Do List)

Proyecto sencillo hecho con Flask y SQLite para gestionar tareas.

## Funciones
- Agregar nueva tarea
- Marcar como completada
- Eliminar tarea

## Tecnolog�as usadas
- Python 3
- Flask
- SQLite

## C�mo ejecutarlo

1. Clona este repositorio.
2. Instala Flask:
